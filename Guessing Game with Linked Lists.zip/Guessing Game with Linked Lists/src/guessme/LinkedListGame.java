package guessme;

public class LinkedListGame {

	private int count;
	private boolean gameOver;
	private LLIntegerNode eliminate;
	private LLIntegerNode head;
	private LLIntegerNode head1;
	private LLIntegerNode tail;
	private int guess;

	public LinkedListGame() {

		count = 0;
		gameOver = false;
		guess = 1000;
		head = new LLIntegerNode(1000, null);
		head1 = new LLIntegerNode(-1, null);
		tail = head1;
		eliminate = head;

		for (int i = 1001; i < 10000; i++) {
			eliminate.setLink(new LLIntegerNode(i, null));
			eliminate = eliminate.getLink();
		}

	}

	// Resets data and game state so we can play again
	public void reset() {
		// TODO
		count = 0;
		gameOver = false;
		guess = 1000;
		head = new LLIntegerNode(1000, null);
		head1 = new LLIntegerNode(-1, null);
		tail = head1;
		eliminate = head;

		for (int i = 1001; i < 10000; i++) {
			eliminate.setLink(new LLIntegerNode(i, null));
			eliminate = eliminate.getLink();
		}

	}

	// Returns true if n is a prior; false otherwise.

	public boolean isPriorGuess(int n) {
		// TODO
		LLIntegerNode answer = head1;

		while (answer != null) {

			if (n == answer.getInfo()) {

				return true;
			}
			answer = answer.getLink();
		}

		return false;

	}

	// Returns the number of guesses.
	public int numGuesses() {
		// TODO
		return count;
	}

	// Returns the number of matches between integers

	public static int numMatches(int a, int b) {
		// TODO
		int matches = 0;

		if ((a % 10) == (b % 10)) {
			matches++;
		}

		if ((a % 100) / 10 == (b % 100) / 10) {
			matches++;
		}

		if ((a % 1000) / 100 == (b % 1000) / 100) {
			matches++;
		}

		if ((a / 1000) == (b / 1000)) {
			matches++;
		}

		return matches;
	}

	/**
	 * Returns true if the game is over; false otherwise.
	 */
	public boolean isOver() {
		// TODO
		return gameOver;
	}

	/*
	 * Returns the guess number and adds it to the list of prior guesses.
	 */
	public int getGuess() {
		// TODO: add guess to the list of prior guesses.
		guess = head.getInfo();
		head = head.getLink();
		tail.setLink(new LLIntegerNode(guess, null));
		tail = tail.getLink();

		if (head1.getInfo() == -1) {
			head1 = head1.getLink();
		}

		count++;
		return guess;
	}

	/**
	 * Updates guess based on the number of matches of the previous guess.
	 */
	public boolean updateGuess(int nmatches) {
		// TODO
		if (nmatches == 4) {
			gameOver = true;
			return true;
		}
		LLIntegerNode answer = head.getLink();
		LLIntegerNode prev = head;

		while (answer != null) {

			if (numMatches(guess, answer.getInfo()) != nmatches) {

				prev.setLink(answer.getLink());

			} else {
				prev = prev.getLink();

			}

			answer = answer.getLink();

		}

		if (numMatches(guess, head.getInfo()) != nmatches) {

			head = head.getLink();

		}
		if (head == null) {

			return false;
		}
		return true;
	}

	// Returns the head of the prior guesses list.
	public LLIntegerNode priorGuesses() {
		// TODO

		if (count == 0 || head1.getInfo() == -1) {

			return null;
		}

		return head1;
	}

	/**
	 * Returns the list of prior guesses as a String.
	 */

	public String priorGuessesString() {
		// TODO
		String guessString = Integer.toString(head1.getInfo());
		LLIntegerNode answer = head1.getLink();
		if (count == 0) {
			return "";
		}
		while (answer != null) {
			guessString = guessString + ", " + Integer.toString(answer.getInfo());
			;
			answer = answer.getLink();
		}
		return guessString;
	}

}
