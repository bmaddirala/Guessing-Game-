package guessme;

/*
 * This class defines a linked list node storing an integer. 
 */
public class LLIntegerNode {
	// TODO
	private int info;
	private LLIntegerNode link;

	public LLIntegerNode(int info, LLIntegerNode link) {
		// TODO Auto-generated constructor stub
		this.info = info;
		this.link = link;
	}

	public int getInfo() {

		return info;
	}

	public void setInfo(int info) {
		this.info = info;
	}

	public LLIntegerNode getLink() {
		return link;
	}

	public void setLink(LLIntegerNode link) {
		this.link = link;
	}

}
