package guessme;

public class ArrayGame {

	private int guess;
	private boolean gameOver;
	private boolean[] eliminate;
	private int number = 10000;
	private int count;
	private int[] counter;

	public ArrayGame() {

		guess = 1000;
		gameOver = false;
		eliminate = new boolean[number];
		for (int i = 1000; i < number; i++) {
			eliminate[i] = false;
		}
		count = 0;
		counter = new int[number];

	}

	// Resets data members and game state so we can play again

	public void reset() {

		guess = 1000;
		gameOver = false;
		eliminate = new boolean[number];
		for (int i = 1000; i < number; i++) {
			eliminate[i] = false;
		}
		count = 0;
		counter = new int[number];

	}

	// Returns true if n is a prior guess

	public boolean isPriorGuess(int n) {

		return eliminate[n];

	}

	// Returns the number of guesses so far.

	public int numGuesses() {

		return count;
	}

	public static int numMatches(int a, int b) {

		int matches = 0;

		if ((a % 10) == (b % 10)) {
			matches++;
		}

		if ((a % 100) / 10 == (b % 100) / 10) {
			matches++;
		}

		if ((a % 1000) / 100 == (b % 1000) / 100) {
			matches++;
		}

		if ((a / 1000) == (b / 1000)) {
			matches++;
		}

		return matches;
	}

	public boolean isOver() {

		return gameOver;
	}

	// Returns the guess number
	public int getGuess() {

		counter[count] = guess;
		eliminate[guess] = true;
		count++;
		return guess;
	}

	/**
	 * Updates guess based on the number of matches of the previous guess.
	 */

	public boolean updateGuess(int nmatches) {

		if (nmatches == 4) {

			gameOver = true;
			return true;

		}
		for (int i = 1000; i < eliminate.length; i++) {

			if (numMatches(guess, i) != nmatches) {

				eliminate[i] = true;
			}

		}

		for (int j = 1000; j < eliminate.length; j++) {

			if (eliminate[j] == false) {

				guess = j;

				return true;
			}
		}

		return false;
	}

	// Returns the list of guesses so far as an integer array.

	public int[] priorGuesses() {

		int[] answer = new int[count];

		if (count == 0) {
			return null;
		}

		for (int i = 0; i < count; i++) {

			answer[i] = counter[i];

		}

		return answer;
	}

}
